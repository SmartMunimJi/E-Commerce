


const UserDashboard = () => {

     return (
        <div>
             <h1>
                THE USER DASHBOARD
             </h1>
             <p>the user details will be fetched here and crud ops for user
                will be available here </p>

        </div>
     );

};

export default UserDashboard;